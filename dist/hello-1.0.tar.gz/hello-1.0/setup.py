from distutils.core import setup

setup(name='hello',
version='1.0',
packages=['hello',],
)
